# ox_structure

## :description:
Definierar mappstruktur i ØX.

core/       → Kärnfiler
modules/    → Huvudmoduler
extensions/ → Tillägg
docs/       → Dokumentation
utils/      → Hjälpfiler