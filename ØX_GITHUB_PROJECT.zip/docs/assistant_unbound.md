# assistant_unbound.md

Dokumentation för UNBOUND-tillägget kopplat till ASSISTANT.