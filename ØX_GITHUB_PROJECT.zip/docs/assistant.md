# assistant.md

Metadata för ØX-modulen ASSISTANT enligt systemstandard.